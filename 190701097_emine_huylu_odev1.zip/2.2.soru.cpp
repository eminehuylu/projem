#include <iostream>

using namespace std;
class OGRENCI{
int notunuz,x,y;



public:
void GirdiAl(){
cout<<"toplam soru sayisini gir:"<<endl;
cout<<"dogru cevap sayisini gir:"<<endl;
cin>>x>>y;
}
void Hesapla(){


notunuz=(100/x)*y;


}
void Goster(){
cout<<"notunuz"<<endl;
cout<<notunuz<<endl;

}


};

int main()
{
OGRENCI ornek;
ornek.GirdiAl();
ornek.Hesapla();
ornek.Goster();

return 0;
}

