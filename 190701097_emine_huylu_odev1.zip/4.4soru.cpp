#include <iostream>
int secenek;
using namespace std;
class HesapMakinesi{

public:
int a,b,e;
void Menu(){
cout<<"Yapilacak Islemi Girin:\n1- Toplama\n2- Cikarma\n3- Carpma\n4- Bolme\n"<<endl;
cin>>secenek;
cout<<"\nA sayisini girin:"<<endl;
cout<<"\nB sayisini girin: "<<endl;
cin>>a>>b;
}
void Toplama(){
e = a+b;
cout<<e<<endl;
}
void Cikarma(){
e = a-b;
cout<<e<<endl;
}
void Carpma(){
e=a*b;
cout<<e<<endl;
}
void Bolme(){
e=a/b;
cout<<e<<endl;
}

};

int main()

{
HesapMakinesi ornek;
ornek.Menu();
if(secenek == 1){
ornek.Toplama();
}
if(secenek == 2){
ornek.Cikarma();
}
if(secenek == 3){
ornek.Carpma();
}
if(secenek == 4){
ornek.Bolme();
}return 0;
}
