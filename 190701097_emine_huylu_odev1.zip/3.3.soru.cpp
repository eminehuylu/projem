#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;
class Zaman{
int h,m,s,zaman;



public:
void GirdiAl(){
cout<<"saati gir:"<<endl;
cout<<"dakikayi gir:"<<endl;
cout<<"saniyeyi gir:"<<endl;
cin>>h>>m>>s;
}

void Goster(){
cout<<"Time is "<<h<<":"<<m<<":"<<s<<endl;
//cout<<zaman<<endl;
}


};

int main()
{
Zaman ornek;
ornek.GirdiAl();

ornek.Goster();

return 0;
}
