#include <iostream>

using namespace std;
class ters{
    private:
    int sayi1,sayi2;
    public:
    void GirdiAl(){
        cout<<"sayi1 gir:"<<endl;
        cout<<"sayi2 gir:"<<endl;
        cin>>sayi1>>sayi2;
        
    }
    void Takas(){
        sayi1 = sayi1 + sayi2;
        sayi2 = sayi1 - sayi2;
        sayi1 = sayi1 - sayi2;
    }
    void Goster(){
        cout<<"takastan sonra sayi1"<<endl;
        cout<<sayi1<<endl;
        cout<<"takastan sonra sayi2"<<endl;
        cout<<sayi2<<endl;
        
    }
    
};

int main()
{
    ters ornek;
    ornek.GirdiAl();
    ornek.Takas();
    ornek.Goster();

    return 0;
}
